import java.util.ArrayList;
import java.util.List;

public class Node {
	
	    private int row;
	    private int column;
	    private boolean visited;
	    private int value;
	    Node[][] matrixNodes;
	    private List<Node> neighbors=new ArrayList<>();

	    public Node(int row, int column, int value, Node[][] matrixNodes){
	        this.row=row;
	        this.column=column;
	        this.value =value;
	        this.matrixNodes=matrixNodes;
	    }


	    public boolean isVisited(){
	        return visited;
	    }
	    public void addNeighbor(Node neighbor){
	        this.neighbors.add(neighbor);

	    }

	    public void setVisited(boolean visited) {
	        this.visited = visited;
	    }

	    public int getRow() {
	        return row;
	    }

	    public void setRow(int row) {
	        this.row = row;
	    }

	    public int getColumn() {
	        return column;
	    }

	    public void setColumn(int column) {
	        this.column = column;
	    }

	    public int getValue() {
	        return value;
	    }

	    public List<Node> getNeighbors()
	    {
	        int matrixRows=matrixNodes.length;
	        int matrixColumns=matrixNodes[0].length;
	        
	        if ((this.row-1)>=Definitions.EMPTY) {
	        
	            if (matrixNodes[row-1][column].getValue()!= Definitions.OBSTACLE) {
	            	
	                neighbors.add(matrixNodes[row-1][column]);
	            }
	        }
	        
	        if ((this.row+1)<matrixRows) {
	        
	            if (matrixNodes[row+1][column].getValue()!=Definitions.OBSTACLE) {
	            	
	                neighbors.add(matrixNodes[row+1][column]);
	            }
	        }
	        
	        if ((this.column+1)<matrixColumns) {
	        
	            if (matrixNodes[row][column+1].getValue()!=Definitions.OBSTACLE) {
	            	
	                neighbors.add(matrixNodes[row][column+1]);
	            }
	        }
	        
	        if ((this.column-1)>=Definitions.EMPTY) {
	        
	            if (matrixNodes[row][column-1].getValue()!=Definitions.OBSTACLE) {
	            	
	                neighbors.add(matrixNodes[row][column-1]);
	            
	            }
	        }
	        
	        return neighbors;
	    }

	    public void setNeighbors(List<Node> neighbors) {
	        this.neighbors = neighbors;
	    }

}
